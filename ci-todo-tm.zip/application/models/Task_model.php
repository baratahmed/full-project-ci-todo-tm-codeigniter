<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task_model extends CI_model {
    
    public function get_task($id){
        $query = $this->db->select('*')
                          ->from('tasks')
                          ->where('id', $id)
                          ->get()->row();
        return $query;
    }

    // public function check_if_complete($id){
    //     $query = $this->db->where('id',$id)
    //                       ->get('tasks')
    //                       ->row()
    //                       ->is_complete;
    //     return $query;
    // }

    public function get_list_name($list_id){
        $this->db->where('id',$list_id);
        $query = $this->db->get('lists');
        return $query->row()->list_name;
    }

    public function create_task($data){
        $insert = $this->db->insert('tasks', $data);
        return $insert;
    }

    public function get_task_list_id($task_id){
        $this->db->where('id',$task_id);
        $query = $this->db->get('tasks');
        return $query->row()->list_id;
    }

    public function get_task_data($task_id){
        $this->db->where('id',$task_id);
        $query = $this->db->get('tasks');
        return $query->row();
    }

    public function edit_task($task_id,$data){
        $this->db->where('id', $task_id);
        $this->db->update('tasks', $data); 
        return TRUE;
    }
    

}
